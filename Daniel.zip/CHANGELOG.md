# 0.1.1

Fixed issing Icon/attribution for the mod.

# 0.1.0

Initial pre-release.